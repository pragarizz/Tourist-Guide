import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {DatabaseSync} from 'node:sqlite';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const publicDir=path.join(__dirname,'public');
const db=new DatabaseSync(path.join(__dirname,'data','tourist-guide.sqlite'));
db.exec(`
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS destinations(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,country TEXT NOT NULL,city TEXT NOT NULL,description TEXT NOT NULL,category TEXT NOT NULL,rating REAL DEFAULT 4.5,image TEXT);
CREATE TABLE IF NOT EXISTS tours(id INTEGER PRIMARY KEY AUTOINCREMENT,destination_id INTEGER NOT NULL,title TEXT NOT NULL,duration TEXT NOT NULL,price REAL NOT NULL,description TEXT NOT NULL,FOREIGN KEY(destination_id) REFERENCES destinations(id));
CREATE TABLE IF NOT EXISTS favorites(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,destination_id INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,destination_id),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(destination_id) REFERENCES destinations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS itineraries(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,destination_id INTEGER NOT NULL,visit_date TEXT NOT NULL,notes TEXT DEFAULT '',FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(destination_id) REFERENCES destinations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS contacts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,name TEXT NOT NULL,email TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL);
`);
if(db.prepare('SELECT COUNT(*) n FROM destinations').get().n===0){
 const a=db.prepare('INSERT INTO destinations(name,country,city,description,category,rating,image) VALUES(?,?,?,?,?,?,?)');
 [
 ['Paris','France','Paris','Eiffel Tower, Louvre, Seine cruises and charming cafés.','Culture',4.8,'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1200&q=80'],
 ['Kyoto','Japan','Kyoto','Temples, gardens, traditional streets and Japanese culture.','Heritage',4.9,'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80'],
 ['Bali','Indonesia','Ubud','Rice terraces, waterfalls, beaches and Balinese traditions.','Nature',4.7,'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=1200&q=80'],
 ['Dubai','UAE','Dubai','Modern architecture, desert adventures, souks and attractions.','Adventure',4.7,'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80'],
 ['Rome','Italy','Rome','Ancient history, Roman landmarks, piazzas and Italian food.','History',4.8,'https://images.unsplash.com/photo-1529260830199-42c24126f198?auto=format&fit=crop&w=1200&q=80'],
 ['Goa','India','Panaji','Beaches, Portuguese heritage, markets and coastal life.','Beach',4.6,'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1200&q=80']
 ].forEach(x=>a.run(...x));
}
if(db.prepare('SELECT COUNT(*) n FROM tours').get().n===0){
 const a=db.prepare('INSERT INTO tours(destination_id,title,duration,price,description) VALUES(?,?,?,?,?)');
 [[1,'Paris Highlights','2 days',149,'Eiffel Tower, Louvre, Seine cruise and Montmartre.'],[2,'Kyoto Heritage Walk','1 day',99,'Fushimi Inari, Gion, Kiyomizu-dera and tea experience.'],[3,'Bali Nature Escape','3 days',229,'Ubud rice terraces, waterfalls and sunrise experience.'],[4,'Dubai Desert Adventure','1 day',129,'Dune safari, sunset camp, dinner and cultural show.'],[5,'Ancient Rome Explorer','2 days',179,'Colosseum, Roman Forum, Pantheon and Vatican area.'],[6,'Goa Coast & Culture','2 days',119,'Beaches, Old Goa churches, markets and local cuisine.']].forEach(x=>a.run(...x));
}
const sessions=new Map();
const hash=p=>{const s=crypto.randomBytes(16).toString('hex');return `${s}:${crypto.scryptSync(p,s,64).toString('hex')}`};
const verify=(p,v)=>{const [s,h]=String(v).split(':');if(!s||!h)return false;const x=crypto.scryptSync(p,s,64).toString('hex');return crypto.timingSafeEqual(Buffer.from(x,'hex'),Buffer.from(h,'hex'))};
function cookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').filter(Boolean).map(x=>{const i=x.indexOf('=');return [x.slice(0,i).trim(),decodeURIComponent(x.slice(i+1))]}))}
function user(req){const id=sessions.get(cookies(req).sid);return id?db.prepare('SELECT id,name,email,created_at FROM users WHERE id=?').get(id):null}
async function jsonBody(req){let s='';for await(const c of req)s+=c;return s?JSON.parse(s):{}}
function send(res,status,data,type='application/json'){res.writeHead(status,{'Content-Type':type+'; charset=utf-8'});res.end(type==='application/json'?JSON.stringify(data):data)}
function need(req,res){const u=user(req);if(!u)send(res,401,{error:'Not authenticated'});return u}
function staticFile(req,res){
 let p=new URL(req.url,'http://x').pathname;if(p==='/')p='/index.html';
 const f=path.normalize(path.join(publicDir,p));if(!f.startsWith(publicDir)||!fs.existsSync(f))return send(res,404,{error:'Not found'});
 const ext=path.extname(f);const t={'.html':'text/html','.css':'text/css','.js':'application/javascript'}[ext]||'text/plain';send(res,200,fs.readFileSync(f),t)
}
const server=http.createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,'http://x'),m=req.method;
  if(m==='GET'&&u.pathname==='/api/health')return send(res,200,{ok:true,service:'WanderWise Tourist Guide API',database:'SQLite',databaseFile:'data/tourist-guide.sqlite'});
  if(m==='POST'&&u.pathname==='/api/register'){const b=await jsonBody(req),name=String(b.name||'').trim(),email=String(b.email||'').trim().toLowerCase(),p=String(b.password||'');if(name.length<2||!email.includes('@')||p.length<8)return send(res,400,{error:'Valid name, email and 8+ character password required'});if(db.prepare('SELECT id FROM users WHERE email=?').get(email))return send(res,409,{error:'Email already registered'});const r=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name,email,hash(p)),sid=crypto.randomBytes(32).toString('hex');sessions.set(sid,Number(r.lastInsertRowid));res.setHeader('Set-Cookie',`sid=${sid}; HttpOnly; SameSite=Lax; Path=/`);return send(res,201,{user:user({headers:{cookie:`sid=${sid}`}})})}
  if(m==='POST'&&u.pathname==='/api/login'){const b=await jsonBody(req),x=db.prepare('SELECT * FROM users WHERE email=?').get(String(b.email||'').trim().toLowerCase());if(!x||!verify(String(b.password||''),x.password_hash))return send(res,401,{error:'Invalid email or password'});const sid=crypto.randomBytes(32).toString('hex');sessions.set(sid,x.id);res.setHeader('Set-Cookie',`sid=${sid}; HttpOnly; SameSite=Lax; Path=/`);return send(res,200,{user:{id:x.id,name:x.name,email:x.email,created_at:x.created_at}})}
  if(m==='POST'&&u.pathname==='/api/logout'){const sid=cookies(req).sid;if(sid)sessions.delete(sid);res.setHeader('Set-Cookie','sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');return send(res,200,{ok:true})}
  if(m==='GET'&&u.pathname==='/api/auth/me'){const x=user(req);return x?send(res,200,{user:x}):send(res,401,{error:'Not authenticated'})}
  if(m==='GET'&&u.pathname==='/api/destinations'){const q=String(u.searchParams.get('q')||''),c=String(u.searchParams.get('category')||'');let sql='SELECT * FROM destinations WHERE 1=1',p=[];if(q){sql+=' AND (name LIKE ? OR country LIKE ? OR city LIKE ?)';const x='%'+q+'%';p.push(x,x,x)}if(c){sql+=' AND category=?';p.push(c)}return send(res,200,{destinations:db.prepare(sql+' ORDER BY rating DESC').all(...p)})}
  if(m==='GET'&&u.pathname==='/api/tours')return send(res,200,{tours:db.prepare('SELECT t.*,d.name destination_name,d.country FROM tours t JOIN destinations d ON d.id=t.destination_id ORDER BY t.price').all()});
  if(m==='GET'&&u.pathname==='/api/dashboard'){const x=need(req,res);if(!x)return;return send(res,200,{user:x,favorites:db.prepare('SELECT d.* FROM favorites f JOIN destinations d ON d.id=f.destination_id WHERE f.user_id=?').all(x.id),itinerary:db.prepare('SELECT i.*,d.name,d.country FROM itineraries i JOIN destinations d ON d.id=i.destination_id WHERE i.user_id=? ORDER BY i.visit_date').all(x.id)})}
  if(m==='POST'&&u.pathname==='/api/favorites'){const x=need(req,res);if(!x)return;const b=await jsonBody(req);db.prepare('INSERT OR IGNORE INTO favorites(user_id,destination_id) VALUES(?,?)').run(x.id,Number(b.destinationId));return send(res,201,{ok:true})}
  if(m==='DELETE'&&u.pathname.startsWith('/api/favorites/')){const x=need(req,res);if(!x)return;db.prepare('DELETE FROM favorites WHERE user_id=? AND destination_id=?').run(x.id,Number(u.pathname.split('/').pop()));return send(res,200,{ok:true})}
  if(m==='POST'&&u.pathname==='/api/itinerary'){const x=need(req,res);if(!x)return;const b=await jsonBody(req);db.prepare('INSERT INTO itineraries(user_id,destination_id,visit_date,notes) VALUES(?,?,?,?)').run(x.id,Number(b.destinationId),String(b.visitDate),String(b.notes||''));return send(res,201,{ok:true})}
  if(m==='DELETE'&&u.pathname.startsWith('/api/itinerary/')){const x=need(req,res);if(!x)return;db.prepare('DELETE FROM itineraries WHERE id=? AND user_id=?').run(Number(u.pathname.split('/').pop()),x.id);return send(res,200,{ok:true})}
  if(m==='POST'&&u.pathname==='/api/contact'){const x=user(req),b=await jsonBody(req);if(!b.name||!b.email||!b.message)return send(res,400,{error:'All fields required'});db.prepare('INSERT INTO contacts(user_id,name,email,message) VALUES(?,?,?,?)').run(x?.id??null,String(b.name),String(b.email),String(b.message));return send(res,201,{message:'Message received'})}
  return staticFile(req,res)
 }catch(e){console.error(e);send(res,500,{error:e.message})}
});
server.listen(5000,()=>console.log('WanderWise Tourist Guide running at http://localhost:5000'));